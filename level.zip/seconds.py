# write module for stopwatch

class Seconds(Label):
   
    def __init__(self, total, **kwargs):
        pass

    def restart(self, total, **kwargs):
        pass

    def start(self):
        pass

    def change(self, dt):
        pass