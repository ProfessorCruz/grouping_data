# write module for working with animation

class Runner(BoxLayout):

    def __init__(self):
        pass

    def start(self):
        pass

    def next(self, widget, step):
        pass