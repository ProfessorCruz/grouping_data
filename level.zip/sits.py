# write module to count squats

class Sits(Label):
    
    def __init__(self, total, **kwargs):
        pass

    def next(self, *args):
        pass